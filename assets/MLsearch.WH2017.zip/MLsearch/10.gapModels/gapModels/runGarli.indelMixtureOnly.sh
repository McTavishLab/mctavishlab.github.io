#!/bin/bash

./runGarli.dna+gapModels.sh dimm
